

const canvas = document.getElementById('screen');
const context = canvas.getContext('2d');

